import React, { useState } from "react";
import { SafeAreaView, View, Text, ScrollView, TouchableOpacity, StatusBar, StyleSheet } from "react-native";
import { Home, ShoppingBag, Package, ChartNoAxesCombined, User, Bell, Plus, ArrowUpRight, Menu } from "lucide-react-native";

const metrics = [
  { label: "Total revenue", value: "৳ 2,48,560", change: "+12.8%" },
  { label: "Total orders", value: "1,284", change: "+8.2%" },
  { label: "Net profit", value: "৳ 68,420", change: "+18.4%" },
  { label: "Customers", value: "856", change: "+6.1%" },
];
const recent = [
  ["#BZ-1048", "Nusrat Jahan", "৳ 1,850", "Pending"],
  ["#BZ-1047", "Tanvir Ahmed", "৳ 2,450", "Processing"],
  ["#BZ-1046", "Sadia Islam", "৳ 1,290", "Delivered"],
];

export default function App() {
  const [tab, setTab] = useState("Home");
  const [bn, setBn] = useState(false);
  const tr = (en, bangla) => bn ? bangla : en;
  return (
    <SafeAreaView style={s.safe}>
      <StatusBar barStyle="dark-content" backgroundColor="#F5F7FB"/>
      <View style={s.header}>
        <View style={s.brandRow}><View style={s.logo}><Menu color="#fff" size={20}/></View><View><Text style={s.brand}>BIZORA</Text><Text style={s.subbrand}>BUSINESS OS</Text></View></View>
        <View style={s.headerRight}>
          <TouchableOpacity onPress={()=>setBn(!bn)} style={s.lang}><Text style={s.langText}>{bn?"বাংলা":"EN"}</Text></TouchableOpacity>
          <TouchableOpacity style={s.bell}><Bell size={19} color="#536078"/></TouchableOpacity>
        </View>
      </View>
      <ScrollView contentContainerStyle={s.content}>
        <Text style={s.eyebrow}>WEDNESDAY, NOVEMBER 12, 2026</Text>
        <Text style={s.title}>{tr("Good morning, Rokib","শুভ সকাল, রকিব")} ✦</Text>
        <Text style={s.description}>{tr("Here’s your business at a glance.","আপনার ব্যবসার সার্বিক অবস্থা একনজরে।")}</Text>
        <View style={s.store}><View style={s.storeIcon}><Text style={s.storeLetter}>R</Text></View><View style={{flex:1}}><Text style={s.storeName}>Reivon Store</Text><Text style={s.storeMeta}>Business workspace</Text></View><Text style={s.pro}>PRO</Text></View>
        <View style={s.grid}>{metrics.map((m,i)=><View key={m.label} style={s.metric}><Text style={s.metricLabel}>{tr(m.label,["মোট বিক্রি","মোট অর্ডার","নিট লাভ","কাস্টমার"][i])}</Text><Text style={s.metricValue}>{m.value}</Text><View style={s.growth}><ArrowUpRight size={13} color="#269B73"/><Text style={s.growthText}>{m.change}</Text></View></View>)}</View>
        <View style={s.sectionHead}><View><Text style={s.sectionTitle}>{tr("Recent orders","সাম্প্রতিক অর্ডার")}</Text><Text style={s.sectionSub}>{tr("Your latest customer activity","সর্বশেষ কাস্টমার কার্যক্রম")}</Text></View><TouchableOpacity><Text style={s.viewAll}>{tr("View all","সব দেখুন")} →</Text></TouchableOpacity></View>
        {recent.map((o,i)=><View style={s.order} key={o[0]}><View style={[s.orderAvatar,{backgroundColor:["#F0EDFF","#EAF3FF","#E9F8F1"][i]}]}><Text style={{color:["#7164D9","#4D8FE1","#32A77A"][i],fontWeight:"700"}}>{o[1].split(" ").map(x=>x[0]).join("")}</Text></View><View style={{flex:1}}><Text style={s.orderName}>{o[1]}</Text><Text style={s.orderId}>{o[0]}</Text></View><View style={{alignItems:"flex-end"}}><Text style={s.orderAmount}>{o[2]}</Text><Text style={[s.orderStatus,{color:i===0?"#D79632":i===1?"#5887D0":"#2D9C72"}]}>{o[3]}</Text></View></View>)}
        <TouchableOpacity style={s.addButton}><Plus size={17} color="#fff"/><Text style={s.addText}>{tr("Add product","পণ্য যোগ করুন")}</Text></TouchableOpacity>
      </ScrollView>
      <View style={s.tabbar}>
        {[["Home",Home],["Orders",ShoppingBag],["Products",Package],["Reports",ChartNoAxesCombined],["Profile",User]].map(([name,Icon])=><TouchableOpacity key={name} style={s.tab} onPress={()=>setTab(name)}><Icon size={20} color={tab===name?"#6558D3":"#929BAD"}/><Text style={[s.tabText,tab===name&&s.tabActive]}>{tr(name,({Home:"হোম",Orders:"অর্ডার",Products:"পণ্য",Reports:"রিপোর্ট",Profile:"প্রোফাইল"})[name])}</Text></TouchableOpacity>)}
      </View>
    </SafeAreaView>
  );
}
const s=StyleSheet.create({
 safe:{flex:1,backgroundColor:"#F5F7FB"},header:{height:65,paddingHorizontal:18,flexDirection:"row",alignItems:"center",justifyContent:"space-between",borderBottomWidth:1,borderBottomColor:"#EDF0F5",backgroundColor:"#fff"},brandRow:{flexDirection:"row",alignItems:"center",gap:10},logo:{width:36,height:36,borderRadius:11,backgroundColor:"#6558D3",alignItems:"center",justifyContent:"center"},brand:{fontSize:16,fontWeight:"800",letterSpacing:2,color:"#172033"},subbrand:{fontSize:8,letterSpacing:1.6,color:"#929BAD"},headerRight:{flexDirection:"row",alignItems:"center",gap:10},lang:{padding:8},langText:{fontSize:12,color:"#536078",fontWeight:"700"},bell:{padding:7},content:{padding:18,paddingBottom:25},eyebrow:{fontSize:9,letterSpacing:1.2,color:"#9AA2B1",fontWeight:"700"},title:{fontSize:23,fontWeight:"800",color:"#172033",marginTop:9},description:{fontSize:12,color:"#929BAD",marginTop:5},store:{marginTop:20,backgroundColor:"#fff",borderRadius:13,padding:12,flexDirection:"row",alignItems:"center",gap:10,borderWidth:1,borderColor:"#EDF0F5"},storeIcon:{width:34,height:34,borderRadius:10,backgroundColor:"#6558D3",alignItems:"center",justifyContent:"center"},storeLetter:{color:"#fff",fontWeight:"800"},storeName:{fontSize:12,fontWeight:"700",color:"#283149"},storeMeta:{fontSize:10,color:"#929BAD",marginTop:3},pro:{fontSize:9,fontWeight:"800",color:"#6558D3",backgroundColor:"#F0EDFF",paddingHorizontal:9,paddingVertical:5,borderRadius:5},grid:{flexDirection:"row",flexWrap:"wrap",gap:10,marginTop:14},metric:{width:"48%",flexGrow:1,backgroundColor:"#fff",borderRadius:12,borderWidth:1,borderColor:"#EDF0F5",padding:13},metricLabel:{fontSize:10,color:"#8992A5"},metricValue:{fontSize:19,fontWeight:"800",color:"#172033",marginTop:12},growth:{flexDirection:"row",alignItems:"center",marginTop:8},growthText:{fontSize:10,color:"#269B73",fontWeight:"700"},sectionHead:{flexDirection:"row",alignItems:"center",justifyContent:"space-between",marginTop:25,marginBottom:12},sectionTitle:{fontSize:14,fontWeight:"800",color:"#172033"},sectionSub:{fontSize:10,color:"#929BAD",marginTop:4},viewAll:{fontSize:10,color:"#6558D3",fontWeight:"700"},order:{backgroundColor:"#fff",borderWidth:1,borderColor:"#EDF0F5",borderRadius:11,padding:12,flexDirection:"row",alignItems:"center",gap:10,marginBottom:8},orderAvatar:{width:34,height:34,borderRadius:10,alignItems:"center",justifyContent:"center"},orderName:{fontSize:11,fontWeight:"700",color:"#394257"},orderId:{fontSize:9,color:"#929BAD",marginTop:4},orderAmount:{fontSize:11,fontWeight:"800",color:"#30394D"},orderStatus:{fontSize:9,marginTop:4,fontWeight:"700"},addButton:{height:43,backgroundColor:"#6558D3",borderRadius:10,alignItems:"center",justifyContent:"center",flexDirection:"row",gap:8,marginTop:13},addText:{fontSize:12,color:"#fff",fontWeight:"700"},tabbar:{height:65,backgroundColor:"#fff",borderTopWidth:1,borderTopColor:"#EDF0F5",flexDirection:"row",justifyContent:"space-around",alignItems:"center"},tab:{alignItems:"center",gap:4,flex:1},tabText:{fontSize:9,color:"#929BAD"},tabActive:{color:"#6558D3",fontWeight:"800"}
});
