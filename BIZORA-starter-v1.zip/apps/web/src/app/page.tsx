"use client";

import { useMemo, useState } from "react";
import {
  Activity, ArrowDownRight, ArrowUpRight, Bell, Box, BriefcaseBusiness,
  ChartNoAxesCombined, ChevronDown, CircleHelp, CreditCard, Download,
  Globe2, LayoutDashboard, LogOut, Menu, Package, Plus, Search, Settings,
  ShoppingBag, ShoppingCart, Users, Wallet, X, Languages, Truck, Tag
} from "lucide-react";

const nav = [
  { label: "Overview", bn: "ওভারভিউ", icon: LayoutDashboard },
  { label: "Orders", bn: "অর্ডার", icon: ShoppingCart, count: "12" },
  { label: "Products", bn: "পণ্য", icon: Package },
  { label: "Customers", bn: "কাস্টমার", icon: Users },
  { label: "Inventory", bn: "ইনভেন্টরি", icon: Box },
  { label: "Payments", bn: "পেমেন্ট", icon: CreditCard },
  { label: "Expenses", bn: "খরচ", icon: Wallet },
  { label: "Marketing", bn: "মার্কেটিং", icon: Tag },
  { label: "Delivery", bn: "ডেলিভারি", icon: Truck },
  { label: "Reports", bn: "রিপোর্ট", icon: ChartNoAxesCombined },
];

const orders = [
  { id: "#BZ-1048", customer: "Nusrat Jahan", product: "Premium Cotton Kurti", date: "12 Nov, 10:32 AM", amount: "৳ 1,850", status: "Pending", initials: "NJ", tone: "violet" },
  { id: "#BZ-1047", customer: "Tanvir Ahmed", product: "Wireless Headphone", date: "12 Nov, 09:18 AM", amount: "৳ 2,450", status: "Processing", initials: "TA", tone: "blue" },
  { id: "#BZ-1046", customer: "Sadia Islam", product: "Skin Care Combo", date: "11 Nov, 08:45 PM", amount: "৳ 1,290", status: "Delivered", initials: "SI", tone: "orange" },
  { id: "#BZ-1045", customer: "Rakib Hasan", product: "Classic Wrist Watch", date: "11 Nov, 06:12 PM", amount: "৳ 3,200", status: "Shipped", initials: "RH", tone: "green" },
];

const bars = [34, 48, 40, 64, 52, 72, 57, 82, 66, 91, 73, 100];

export default function Dashboard() {
  const [bangla, setBangla] = useState(false);
  const [active, setActive] = useState("Overview");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [showAdd, setShowAdd] = useState(false);
  const t = (en: string, bn: string) => bangla ? bn : en;
  const filtered = useMemo(() => orders.filter(o => `${o.id} ${o.customer} ${o.product}`.toLowerCase().includes(query.toLowerCase())), [query]);

  return (
    <main className="app-shell">
      <aside className={`sidebar ${mobileOpen ? "open" : ""}`}>
        <div className="brand">
          <div className="brand-mark"><BriefcaseBusiness size={22}/></div>
          <div><strong>BIZORA</strong><small>BUSINESS OS</small></div>
          <button className="mobile-close icon-btn" onClick={() => setMobileOpen(false)} aria-label="Close menu"><X size={19}/></button>
        </div>
        <div className="workspace">
          <div className="workspace-avatar">R</div>
          <div className="workspace-copy"><b>Reivon Store</b><span>Business workspace</span></div>
          <ChevronDown size={15} className="muted"/>
        </div>
        <div className="nav-label">{t("WORKSPACE", "ওয়ার্কস্পেস")}</div>
        <nav>
          {nav.map(({label,bn,icon:Icon,count}) => (
            <button key={label} className={`nav-item ${active===label ? "active" : ""}`} onClick={() => {setActive(label);setMobileOpen(false);}}>
              <Icon size={18}/><span>{t(label,bn)}</span>{count && <em>{count}</em>}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <button className={`nav-item ${active==="Settings"?"active":""}`} onClick={()=>setActive("Settings")}><Settings size={18}/><span>{t("Settings","সেটিংস")}</span></button>
          <div className="plan-card"><div className="plan-top"><span>YOUR PLAN</span><span className="plan-badge">PRO</span></div><b>{t("Grow without limits","সীমাহীনভাবে এগিয়ে যান")}</b><div className="plan-progress"><i/></div><small>18 of 50 products used</small><button onClick={()=>setActive("Subscription")}>{t("Manage plan","প্ল্যান পরিচালনা")} →</button></div>
          <div className="profile"><div className="profile-avatar">RW</div><div><b>Rokib Web</b><small>Store Owner</small></div><button className="icon-btn" aria-label="Profile menu"><LogOut size={16}/></button></div>
        </div>
      </aside>

      {mobileOpen && <button className="scrim" onClick={()=>setMobileOpen(false)} aria-label="Close navigation"/>}
      <section className="main-area">
        <header className="topbar">
          <div className="top-left"><button className="mobile-menu icon-btn" onClick={()=>setMobileOpen(true)} aria-label="Open menu"><Menu/></button><div className="breadcrumb">Workspace <span>/</span> <b>{active}</b></div></div>
          <div className="top-actions">
            <label className="searchbox"><Search size={16}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder={t("Search orders, products...","অর্ডার বা পণ্য খুঁজুন...")}/><kbd>⌘ K</kbd></label>
            <button className="language-btn" onClick={()=>setBangla(!bangla)}><Globe2 size={16}/>{bangla?"বাংলা":"EN"}<ChevronDown size={14}/></button>
            <button className="icon-btn notification" aria-label="Notifications"><Bell size={18}/><i/></button>
            <div className="top-avatar">RW</div>
          </div>
        </header>

        <div className="content">
          <div className="welcome-row">
            <div><div className="eyebrow">{t("WEDNESDAY, NOVEMBER 12, 2026","বুধবার, ১২ নভেম্বর, ২০২৬")}</div><h1>{t("Good morning, Rokib","শুভ সকাল, রকিব")} <span>✦</span></h1><p>{t("Here’s what’s happening with your business today.","আজ আপনার ব্যবসার সার্বিক অবস্থা একনজরে দেখে নিন।")}</p></div>
            <div className="welcome-actions"><button className="btn-secondary"><Download size={16}/>{t("Export report","রিপোর্ট ডাউনলোড")}</button><button className="btn-primary" onClick={()=>setShowAdd(true)}><Plus size={17}/>{t("Add product","পণ্য যোগ করুন")}</button></div>
          </div>

          <div className="stats-grid">
            <Stat title={t("Total revenue","মোট বিক্রি")} value="৳ 2,48,560" change="+12.8%" note={t("vs. last month","গত মাসের তুলনায়")} icon={<Wallet/>} tone="purple"/>
            <Stat title={t("Total orders","মোট অর্ডার")} value="1,284" change="+8.2%" note={t("vs. last month","গত মাসের তুলনায়")} icon={<ShoppingBag/>} tone="blue"/>
            <Stat title={t("Net profit","নিট লাভ")} value="৳ 68,420" change="+18.4%" note={t("vs. last month","গত মাসের তুলনায়")} icon={<ChartNoAxesCombined/>} tone="green"/>
            <Stat title={t("Customers","কাস্টমার")} value="856" change="+6.1%" note={t("vs. last month","গত মাসের তুলনায়")} icon={<Users/>} tone="orange"/>
          </div>

          <div className="dashboard-grid">
            <section className="panel revenue-panel">
              <div className="panel-head"><div><h2>{t("Revenue overview","বিক্রির সারাংশ")}</h2><p>{t("Track your sales performance over time","সময়ের সঙ্গে বিক্রির অগ্রগতি")}</p></div><select aria-label="Revenue period"><option>{t("Last 12 months","গত ১২ মাস")}</option><option>{t("Last 30 days","গত ৩০ দিন")}</option></select></div>
              <div className="revenue-total"><strong>৳ 2,48,560</strong><span><ArrowUpRight size={15}/> 12.8%</span><small>{t("Total revenue this year","এই বছরের মোট বিক্রি")}</small></div>
              <div className="chart"><div className="y-labels"><span>৳3L</span><span>৳2L</span><span>৳1L</span><span>৳0</span></div><div className="chart-main"><div className="grid-lines"><i/><i/><i/><i/></div><div className="bars">{bars.map((h,i)=><div className="bar-wrap" key={i}><div className={`bar ${i===11?"highlight":""}`} style={{height:`${h}%`}}/><span>{["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][i]}</span></div>)}</div></div></div>
            </section>
            <section className="panel channel-panel">
              <div className="panel-head"><div><h2>{t("Sales channels","বিক্রির মাধ্যম")}</h2><p>{t("Where your orders come from","অর্ডার আসছে যেখান থেকে")}</p></div><button className="dots">•••</button></div>
              <div className="donut-wrap"><div className="donut"><div><b>1,284</b><small>{t("Orders","অর্ডার")}</small></div></div></div>
              <div className="channel-legend"><Legend color="#6758d8" label="Website" value="58%"/><Legend color="#28a879" label="Facebook" value="27%"/><Legend color="#e7a34b" label="Other" value="15%"/></div>
            </section>
          </div>

          <section className="panel orders-panel">
            <div className="panel-head"><div><h2>{t("Recent orders","সাম্প্রতিক অর্ডার")}</h2><p>{t("Keep track of your latest customer orders","সর্বশেষ কাস্টমার অর্ডারগুলো দেখুন")}</p></div><button className="text-link" onClick={()=>setActive("Orders")}>{t("View all orders","সব অর্ডার দেখুন")} →</button></div>
            <div className="table-wrap"><table><thead><tr><th>{t("ORDER ID","অর্ডার আইডি")}</th><th>{t("CUSTOMER","কাস্টমার")}</th><th>{t("PRODUCT","পণ্য")}</th><th>{t("DATE","তারিখ")}</th><th>{t("AMOUNT","পরিমাণ")}</th><th>{t("STATUS","স্ট্যাটাস")}</th></tr></thead><tbody>{filtered.map(o=><tr key={o.id}><td className="order-id">{o.id}</td><td><div className="customer-cell"><span className={`customer-avatar ${o.tone}`}>{o.initials}</span>{o.customer}</div></td><td>{o.product}</td><td className="date-cell">{o.date}</td><td className="amount">{o.amount}</td><td><span className={`status ${o.status.toLowerCase()}`}>{t(o.status,({Pending:"অপেক্ষমাণ",Processing:"প্রসেসিং",Delivered:"ডেলিভারি সম্পন্ন",Shipped:"পাঠানো হয়েছে"} as Record<string,string>)[o.status])}</span></td></tr>)}</tbody></table>{filtered.length===0&&<div className="empty">No matching demo orders found.</div>}</div>
          </section>
          <footer><span>© 2026 BIZORA. {t("All rights reserved.","সর্বস্বত্ব সংরক্ষিত।")}</span><span><CircleHelp size={14}/> {t("Help center","সহায়তা কেন্দ্র")}　·　{t("Privacy","গোপনীয়তা")}</span></footer>
        </div>
      </section>
      {showAdd && <div className="modal-backdrop" onClick={()=>setShowAdd(false)}><div className="modal" onClick={e=>e.stopPropagation()}><button className="modal-close icon-btn" onClick={()=>setShowAdd(false)}><X/></button><div className="modal-icon"><Package/></div><h2>{t("Add your first product","আপনার প্রথম পণ্য যোগ করুন")}</h2><p>{t("Product creation will connect to your secure business workspace in the next build step.","পরবর্তী ধাপে নিরাপদ ডেটাবেসের সঙ্গে পণ্য যোগ করার সুবিধা যুক্ত হবে।")}</p><label>Product name<input placeholder="e.g. Premium Cotton Kurti"/></label><label>Price (BDT)<input placeholder="1850" type="number"/></label><button className="btn-primary full" onClick={()=>setShowAdd(false)}>Got it</button></div></div>}
    </main>
  );
}

function Stat({title,value,change,note,icon,tone}:{title:string;value:string;change:string;note:string;icon:React.ReactNode;tone:string}) {
  return <div className="stat-card"><div className="stat-top"><span>{title}</span><div className={`stat-icon ${tone}`}>{icon}</div></div><strong>{value}</strong><div className="stat-foot"><span className="growth"><ArrowUpRight size={14}/>{change}</span><small>{note}</small></div></div>;
}
function Legend({color,label,value}:{color:string;label:string;value:string}) { return <div className="legend-row"><span><i style={{background:color}}/>{label}</span><b>{value}</b></div>; }
