-- BIZORA multi-tenant foundation
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  preferred_language text not null default 'en' check (preferred_language in ('en','bn')),
  created_at timestamptz not null default now()
);

create table if not exists public.businesses (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  currency text not null default 'BDT',
  owner_id uuid not null references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists public.business_members (
  business_id uuid not null references public.businesses(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'owner' check (role in ('owner','admin','manager','staff')),
  created_at timestamptz not null default now(),
  primary key (business_id,user_id)
);

create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  name text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  category_id uuid references public.categories(id) on delete set null,
  name text not null,
  sku text,
  description text,
  purchase_price numeric(12,2) not null default 0 check (purchase_price >= 0),
  sale_price numeric(12,2) not null default 0 check (sale_price >= 0),
  stock_quantity integer not null default 0 check (stock_quantity >= 0),
  image_url text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (business_id,sku)
);

create table if not exists public.customers (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  name text not null,
  phone text,
  email text,
  address text,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  customer_id uuid references public.customers(id) on delete set null,
  order_number text not null,
  status text not null default 'pending' check (status in ('pending','confirmed','processing','shipped','delivered','cancelled','refunded')),
  subtotal numeric(12,2) not null default 0,
  discount numeric(12,2) not null default 0,
  delivery_fee numeric(12,2) not null default 0,
  total numeric(12,2) not null default 0,
  payment_status text not null default 'unpaid' check (payment_status in ('unpaid','paid','partially_paid','refunded')),
  notes text,
  created_at timestamptz not null default now(),
  unique (business_id,order_number)
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  quantity integer not null check (quantity > 0),
  unit_price numeric(12,2) not null check (unit_price >= 0),
  line_total numeric(12,2) not null check (line_total >= 0)
);

create table if not exists public.expenses (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  title text not null,
  category text,
  amount numeric(12,2) not null check (amount > 0),
  expense_date date not null default current_date,
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null unique references public.businesses(id) on delete cascade,
  plan text not null default 'free' check (plan in ('free','starter','business','premium')),
  status text not null default 'trial' check (status in ('trial','active','past_due','cancelled')),
  current_period_end timestamptz,
  created_at timestamptz not null default now()
);

create or replace function public.is_business_member(target_business uuid)
returns boolean language sql security definer stable set search_path = public
as $$
  select exists (
    select 1 from public.business_members
    where business_id = target_business and user_id = auth.uid()
  );
$$;

alter table public.profiles enable row level security;
alter table public.businesses enable row level security;
alter table public.business_members enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.customers enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.expenses enable row level security;
alter table public.subscriptions enable row level security;

create policy "profile read own" on public.profiles for select using (id = auth.uid());
create policy "profile update own" on public.profiles for update using (id = auth.uid()) with check (id = auth.uid());
create policy "profile insert own" on public.profiles for insert with check (id = auth.uid());

create policy "business members can read business" on public.businesses for select using (public.is_business_member(id));
create policy "owner can create business" on public.businesses for insert with check (owner_id = auth.uid());
create policy "business owner can update" on public.businesses for update using (owner_id = auth.uid()) with check (owner_id = auth.uid());

create policy "members can read membership" on public.business_members for select using (user_id = auth.uid() or public.is_business_member(business_id));
create policy "owner can add members" on public.business_members for insert with check (
  exists (select 1 from public.businesses b where b.id = business_id and b.owner_id = auth.uid())
);
create policy "owner can remove members" on public.business_members for delete using (
  exists (select 1 from public.businesses b where b.id = business_id and b.owner_id = auth.uid())
);

create policy "members manage categories" on public.categories for all using (public.is_business_member(business_id)) with check (public.is_business_member(business_id));
create policy "members manage products" on public.products for all using (public.is_business_member(business_id)) with check (public.is_business_member(business_id));
create policy "members manage customers" on public.customers for all using (public.is_business_member(business_id)) with check (public.is_business_member(business_id));
create policy "members manage orders" on public.orders for all using (public.is_business_member(business_id)) with check (public.is_business_member(business_id));
create policy "members manage order items" on public.order_items for all using (public.is_business_member(business_id)) with check (public.is_business_member(business_id));
create policy "members manage expenses" on public.expenses for all using (public.is_business_member(business_id)) with check (public.is_business_member(business_id));
create policy "members read subscription" on public.subscriptions for select using (public.is_business_member(business_id));

create index if not exists idx_products_business on public.products(business_id);
create index if not exists idx_orders_business_created on public.orders(business_id,created_at desc);
create index if not exists idx_customers_business on public.customers(business_id);
create index if not exists idx_expenses_business_date on public.expenses(business_id,expense_date desc);
