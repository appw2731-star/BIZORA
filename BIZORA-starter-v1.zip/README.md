# BIZORA — SaaS starter

A bilingual (Bangla/English) multi-business management platform starter.

## Included
- `apps/web`: Next.js dashboard starter with responsive premium UI
- `apps/mobile`: Expo / React Native Android starter
- `supabase/schema.sql`: multi-tenant database foundation with Row Level Security
- `.env.example`: environment variables template

## Important
This is a runnable **starter/MVP foundation**, not a finished production commerce platform.
Payment gateways, courier APIs, SMS, subscription billing, audit logging, and complete CRUD flows need provider credentials and further implementation.

## Requirements
- Node.js 20+
- npm
- Supabase project (for database/auth integration)

## Run the website
```bash
cd apps/web
npm install
cp ../../.env.example .env.local
npm run dev
```
Open http://localhost:3000

The dashboard UI works in demo mode without Supabase credentials. To enable Supabase:
1. Create a Supabase project.
2. Run `supabase/schema.sql` in the Supabase SQL Editor.
3. Add the project URL and anon key to `apps/web/.env.local`.

## Run Android app
```bash
cd apps/mobile
npm install
npx expo start
```
Install Expo Go on Android and scan the QR code, or use an Android emulator.
For a standalone Android build, configure EAS Build after setting up an Expo account.

## GitHub + Vercel
- Push this repository to GitHub.
- In Vercel, import the repository.
- Set Root Directory to `apps/web`.
- Add `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY`.
- Deploy.

## Multi-tenant security
Every business-owned row includes `business_id`. The SQL enables Row Level Security and provides policies based on membership. Review and test policies with real accounts before production use. Never put the Supabase service-role key in browser/mobile code.

## Suggested next implementation steps
1. Real sign-up/sign-in and business onboarding
2. Product CRUD + image storage
3. Order workflow and invoice generation
4. Income/expense ledger and reports
5. Super-admin console and subscription plans
6. Payment/courier provider integrations
7. Android authentication and API integration
